#include <iostream>
#include <string.h>
using namespace std;

class Carro {
private:
        string marca;
        string modelo;
        bool ligado;
        int velocidade;
        double valor;

public:
        Carro(string marca, string modelo){
            this->marca = marca;
            this->modelo = modelo;
        }
        Carro(string marca, string modelo, double valor){
            this->marca = marca;
            this->modelo = modelo;
            //this->valor = valor < 0 ? 0 : valor;
            if(valor < 0){
                this->valor = 0;
            } else {
                this->valor = valor;
            }
        }

        string pegaMarca(){
            return this->marca;
        }
        void defineMarca(string marca){
            this->marca = marca;
        }
        string pegaModelo(){
            return this->modelo;
        }
        void defineModelo(string modelo){
            this->modelo = modelo;
        }
        double pegaValor(){
            return this->valor;
        }
        void defineValor(double valor){
             if(valor < 0){
                this->valor = 0;
            } else {
                this->valor = valor;
            }
        }
        int pegaVelocidade(){
            return this->velocidade;
        }
        void defineVelocidade(int velocidade){
            this->velocidade = velocidade;
        }
        bool estaLigado(){
            return this->ligado;
        }
        void defineLigado(bool ligado){
            this->ligado = ligado;
        }

       void ligarDesligar(bool ligando){
                if(ligando == true)
                    this->ligado = true;
                else
                    this->ligado = false;
       }

       int acelerar(bool acelerando){
            if(this->ligado == true){
                if(acelerando == true){
                    if(this->velocidade < 20)
                        this->velocidade += 5;
                } else if(this->velocidade >= 5) {
                    this->velocidade -= 5;
                }
            }
            return this->velocidade;
       }

};

int main()
{
    Carro *carro4 = new Carro("BMW", "X4");
    cout << "Marca: " << carro4->pegaMarca() << endl;
    string marca;
    cin >> marca;
    string modelo;
    cin >> modelo;

    Carro carro(marca, modelo);

    cout << carro.pegaValor() << endl;

    //carro.modelo = "Focus";
    carro.ligarDesligar(true);
    carro.acelerar(true);
    carro.acelerar(true);
    carro.acelerar(false);
    carro.acelerar(false);
    carro.acelerar(false);
    cout << "Marca: " << carro.pegaMarca()<< ". Modelo: " << carro.pegaModelo()<< endl;
    cout << "Ligado: " << carro.estaLigado()<< ". Velocidade: " << carro.pegaVelocidade()<< endl;
    Carro carro2("Fiat", "Argo", -50000);

    carro2.defineModelo("Argo");
    carro2.ligarDesligar(true);
    carro2.acelerar(true);
     cout << "Marca: " << carro2.pegaMarca() << ". Modelo: " << carro2.pegaModelo()<< endl;
     cout << "Ligado: " << carro2.estaLigado()<< ". Velocidade: " << carro2.pegaVelocidade()<< "Valor: " << carro2.pegaValor() << endl;
    carro2.defineValor(-50000);
    cout << "Ligado: " << carro2.estaLigado()<< ". Velocidade: " << carro2.pegaVelocidade()<< "Valor: " << carro2.pegaValor() << endl;
    return 0;
}
