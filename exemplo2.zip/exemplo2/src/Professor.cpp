#include "Professor.h"

Professor::Professor()
{
    //ctor
}

Professor::~Professor()
{
    //dtor
}
