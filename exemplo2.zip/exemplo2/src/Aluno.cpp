#include "Aluno.h"

Aluno::Aluno()
{
    //ctor
}

Aluno::~Aluno()
{
    //dtor
}

Aluno::Aluno(string nome, string turma) : Pessoa(nome){
        this->turma = turma;
}
void Aluno::setTurma(string turma){
    this->turma = turma;
}
string Aluno::getTurma(){
    return this->turma;
}

void Aluno::mostrarDados(){
    Pessoa::mostrarDados();
    cout << "Turma: " << this->turma << endl;
}
