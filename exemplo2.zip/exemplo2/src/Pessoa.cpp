#include "Pessoa.h"

Pessoa::Pessoa()
{
    //ctor
}

Pessoa::~Pessoa()
{
    //dtor
}

 Pessoa::Pessoa(string nome){
     this->nome = nome;
 }
 Pessoa::Pessoa(string nome, string cpf){
     this->nome = nome;
     this->cpf = cpf;
 }
string Pessoa::getNome(){
    return this->nome;
}
void Pessoa::setNome(string nome){
    this->nome = nome;
}
int Pessoa::getIdade(){
    return this->idade;
}
void Pessoa::setIdade(int idade){
    this->idade = idade;
}
float Pessoa::getAltura(){
    return this->altura;
}
void Pessoa::setAltura(float altura){
    this->altura = altura;
}
string Pessoa::getCPF(){
    return this->cpf;
}
void Pessoa::setCPF(string cpf){
    this->cpf = cpf;
}

void Pessoa::mostrarDados(){
    cout << "Nome: " << this->nome << endl;
    cout << "Idade: " << this->idade<< endl;
    cout << "Altura: " << this->altura << endl;
    cout << "CPF: " << this->cpf << endl;
}


