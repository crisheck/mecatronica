#ifndef PESSOA_H
#define PESSOA_H
#include <iostream>

using namespace std;

class Pessoa
{
    public:
        Pessoa();
        Pessoa(string nome);
        Pessoa(string nome, string cpf);
        virtual ~Pessoa();
        string getNome();
        void setNome(string nome);
        int getIdade();
        void setIdade(int idade);
        float getAltura();
        void setAltura(float altura);
        string getCPF();
        void setCPF(string cpf);

        void mostrarDados();
    protected:

    private:
        string nome;
        int idade;
        float altura;
        string cpf;
};

#endif // PESSOA_H
