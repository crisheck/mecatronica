#ifndef PROFESSOR_H
#define PROFESSOR_H
#include <Pessoa.h>

class Professor : public Pessoa
{
    public:
        Professor();
        virtual ~Professor();

        void mostrarDados();
    protected:

    private:
        float salario;
};

#endif // PROFESSOR_H
