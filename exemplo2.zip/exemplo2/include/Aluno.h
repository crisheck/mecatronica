#ifndef ALUNO_H
#define ALUNO_H
#include "Pessoa.h"

class Aluno : public Pessoa
{
    public:
        Aluno();
        Aluno(string nome, string turma);
        virtual ~Aluno();
        void setTurma(string turma);
        string getTurma();

        void mostrarDados();
    protected:

    private:
        string turma;
};

#endif // ALUNO_H
