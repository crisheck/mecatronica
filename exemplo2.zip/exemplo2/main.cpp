#include <iostream>
#include <Aluno.h>
#include <Professor.h>
using namespace std;

int main()
{
    Pessoa pessoa1;
    pessoa1.setNome("Cristhian");
    Pessoa pessoa2("Jamal");
    pessoa1.mostrarDados();
    pessoa2.mostrarDados();
    Aluno aluno1;
    aluno1.setNome("Jamile");
    aluno1.setTurma("Prog1");
    aluno1.mostrarDados();

    Aluno aluno2("Jackson","F�sica");
    aluno2.mostrarDados();
    Professor professor;

    return 0;
}
